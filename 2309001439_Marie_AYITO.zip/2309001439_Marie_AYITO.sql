-- AYITO Marie Guyse-Laure

create database Real_Estate_Management_System;
use Real_Estate_Management_System;

/*CREATE TABLES*/

-- create table clients
create table clients(clientID int primary key,
firstname varchar(50) not null,
lastname varchar(50) not null,
contact varchar(50) not null,
email varchar(50));

-- create table properties
create table properties(propertieID varchar(10) primary key,
address varchar(50) not null,
model varchar(50) not null,price decimal not null,
statut varchar(15) not null);

-- create table agents
create table agents(agentID int primary key,name varchar(100) not null,
phone varchar(50) not null,
email varchar(50));

-- create table transactions
create table transactions(transactionID int auto_increment primary key,
clientID int,
propertieID varchar(10),
agentID int,
transactionDate date,
amount decimal,
foreign key (clientID) references clients(clientID),
foreign key (propertieID) references properties(propertieID),
foreign key (agentID) references agents(agentID));

-- create table payments
create table payments(paymentID int auto_increment primary key,
transactionID int,
amount decimal not null,
paymentDate date not null,
foreign key (transactionID) references transactions(transactionID));

-- create table maintenanceRequests
create table Maintenancerequests(requestID int primary key,
propertieID int,
clientID int,
requestDate date not null,
foreign key (propertieID) references properties(propertieID),
foreign key (clientID) references clients(clientID));

-- create table propertieImages
create table PertieImages(imageID int primary key,
propertieID int,
imageURL varchar(200) not null,
foreign key (propertieID) references properties(propertieID));

/*INSERT SOME VALUES*/

-- Insert into clients
insert into clients (clientID, firstname, lastname, contact, email) values
(1, 'John', 'Doe', '1234567890', 'john.doe@example.com'),
(2, 'Jane', 'Smith', '0987654321', 'jane.smith@example.com'),
(3, 'Alice', 'Johnson', '1122334455', 'alice.johnson@example.com'),
(4, 'Bob', 'Brown', '2233445566', 'bob.brown@example.com'),
(5, 'Charlie', 'Davis', '3344556677', 'charlie.davis@example.com');

-- Insert into properties
insert into properties (propertieID, address, model, price, statut) values
('P001', '123 Main St', 'Villa', 250000, 'Available'),
('P002', '456 Elm St', 'Apartment', 180000, 'Sold'),
('P003', '789 Oak St', 'Townhouse', 220000, 'Available'),
('P004', '321 Pine St', 'Condo', 200000, 'Pending'),
('P005', '654 Maple St', 'Bungalow', 275000, 'Available');

-- Insert into agents
insert into agents (agentID, name, phone, email) values
(1, 'Michael Johnson', '5551234567', 'michael.johnson@example.com'),
(2, 'Sarah Williams', '5559876543', 'sarah.williams@example.com'),
(3, 'David Martinez', '5556543210', 'david.martinez@example.com'),
(4, 'Emily Garcia', '5557654321', 'emily.garcia@example.com'),
(5, 'James Anderson', '5558765432', 'james.anderson@example.com');

-- Insert into transactions
insert into transactions (transactionID, clientID, propertieID, agentID, transactionDate, amount) values
(1, 4, 'P001', 1, '2024-01-10', 250000),
(2, 2, 'P002', 2, '2024-01-12', 180000),
(3, 1, 'P003', 3, '2024-01-15', 220000),
(4, 5, 'P004', 4, '2024-01-18', 200000),
(5, 3, 'P005', 5, '2024-01-20', 275000);

-- Insert into payments
insert into payments (paymentID, transactionID, amount, paymentDate) values
(1, 3, 250000, '2024-01-11'),
(2, 2, 180000, '2024-01-13'),
(3, 5, 220000, '2024-01-16'),
(4, 4, 200000, '2024-01-19'),
(5, 1, 275000, '2024-01-21');

-- Insert into maintenanceRequests
insert into maintenanceRequests (requestID, propertieID, clientID, requestDate) values
(1, 'P002', 1, '2024-02-01'),
(2, 'P005', 2, '2024-02-02'),
(3, 'P001', 3, '2024-02-03'),
(4, 'P004', 4, '2024-02-04'),
(5, 'P003', 5, '2024-02-05');

-- Insert into propertieImages
insert into propertieImages (imageID, propertieID, imageURL) values
(1, 'P001', 'http://example.com/images/p001.jpg'),
(2, 'P002', 'http://example.com/images/p002.jpg'),
(3, 'P003', 'http://example.com/images/p003.jpg'),
(4, 'P004', 'http://example.com/images/p004.jpg'),
(5, 'P005', 'http://example.com/images/p005.jpg');


/* PERFORM SQL OPERATIONS(CRUD)*/

-- 1)Clients

-- a)CREATE
insert into clients(clientID, firstname, lastname, contact, email)
values(6,'Max','Joe','1234567890', 'max.joe@example.com');
-- b)READ
select * from clients where clientID = 3;
-- c)UPDATE
update clients set contact = '987-654-3210' where clientID = 1;
-- d)DELETE
delete from clients where clientID = 5;


-- 2)Properties

-- a)CREATE
insert into properties (propertieID, address, model, price, statut) 
values ('P006', '123 Main St', 'Villa', 250000, 'Available');
-- b)READ
select * from properties where model = 'Townhouse';
-- c)UPDATE
update properties SET statut = 'Sold' where price = '250000';
-- d)DELETE
delete from properties where price = '275000';

-- 3)Agents

-- a)CREATE
insert into agents (agentID, name, phone, email) 
values (1, 'Alice Johnson', '555-1234', 'alice@example.com');
-- b)READ
select * from agents where agentID = 1;
-- c)UPDATE
update agents set phone = '555-5678' where agentID = 1;
-- d)DELETE
delete from agents where agentID = 1;

-- 4)Transactions

-- a)CREATE
insert into transactions (clientID, propertieID, agentID, transactionDate, amount) 
values (1, 'P001', 1, '2025-01-30', 250000.00);
-- b)READ
select * from transactions where transactionID = 1;
-- c)UPDATE
update transactions set amount = 260000.00 where transactionID = 1;
-- d)DELETE
delete from transactions where transactionID = 1;

-- 5)Payments

-- a)CREATE
insert into payments (transactionID, amount, paymentDate) 
values (1, 50000.00, '2025-02-01');

select * from payments where paymentID = 1;
update payments set amount = 60000 where paymentID = 1;

delete from payments where paymentID = 1;

-- 6)Maintenance Request
insert into maintenanceRequests (propertieID, clientID, requestDate) 
values ('P001', 1, '2025-03-10');

select * from maintenanceRequests where requestID = 1;

update maintenanceRequests set requestDate = '2025-03-15' where requestID = 1;

delete from maintenanceRequests where requestID = 1;

-- 7)Property Images
insert into propertieImages (propertieID, imageURL) 
values ('P001', 'https://example.com/image1.jpg');

select * from propertieImages where imageID = 1;

update propertieImages set imageURL = 'https://example.com/new_image.jpg' where imageID = 1;

delete from propertieImages where imageID = 1;

-- Clients Table
SELECT COUNT(ClientID) FROM Clients;  
SELECT AVG(TransactionCount) FROM (SELECT COUNT(*) AS TransactionCount FROM Transactions GROUP BY ClientID);  
SELECT SUM(Amount) FROM Payments;

-- Properties Table
SELECT COUNT(PropertieID) FROM Properties; 
SELECT AVG(Price) FROM Properties; 
SELECT SUM(Price) FROM Properties WHERE Type = 'Sale';

-- Agents Table
SELECT COUNT(AgentID) FROM Agents;  
SELECT AVG(ListedPropertiesCount) FROM (SELECT COUNT(*) AS ListedPropertiesCount FROM Properties GROUP BY AgentID);  
SELECT SUM(Commission) FROM Agents;  

-- Transactionx Table
SELECT COUNT(TransactionID) FROM Transactions; 
SELECT AVG(Price) FROM Transactions;  
SELECT SUM(Price) FROM Transactions;  

-- Payments Table
SELECT COUNT(PaymentID) FROM Payments; 
SELECT AVG(Amount) FROM Payments;
SELECT SUM(Amount) FROM Payments; 

-- Maintenance Requests Table
SELECT COUNT(RequestID) FROM MaintenanceRequests;  
SELECT AVG(RequestCount) FROM (SELECT COUNT(*) AS RequestCount FROM MaintenanceRequests GROUP BY PropertyID);  
SELECT SUM(Cost) FROM MaintenanceRequests;  

-- Propertie Images Table
SELECT COUNT(ImageID) FROM PropertieImages;  
SELECT AVG(ImageCount) FROM (SELECT COUNT(*) AS ImageCount FROM PropertieImages GROUP BY PropertieID);  
SELECT SUM(Size) FROM PropertieImages;  


 /*Perform PL/SQL Operations
 
 CREATION OF SIX DIFFERENTS VIEWS*/
 
 -- 1)create view clients_transctions
 CREATE VIEW ClientTransactions AS
SELECT t.transactionID, c.firstname, c.lastname, p.address, t.transactionDate, t.amount
FROM transactions t
JOIN clients c ON t.clientID = c.clientID
JOIN properties p ON t.propertieID = p.propertieID;
 
 -- 2)Create a View for active properties
 CREATE VIEW ActiveProperties AS
SELECT propertieID, address, model, price, statut
FROM properties
WHERE statut = 'Available';

-- 3)create view of property_address
CREATE VIEW PropertyAddresses AS
SELECT propertieID, address, model
FROM properties;

-- 4)create view PropertiesAbove20.000$
CREATE VIEW PropertiesAbove200K AS
SELECT propertieID, address, price
FROM properties
WHERE price > 200000;

-- 5)create view of client informations
CREATE VIEW ClientInfo AS
SELECT clientID, firstname, lastname
FROM clients;

-- 6)create view of AgentsWithSales
CREATE VIEW AgentsWithSales AS
SELECT a.name, p.address
FROM agents a
JOIN transactions t ON a.agentID = t.agentID
JOIN properties p ON t.propertieID = p.propertieID
WHERE p.statut = 'Sold';


/*6 differents Stored Procedures*/

-- 1)a)procedure add a new client
DELIMITER //
CREATE PROCEDURE AddClient(
    IN p_clientID INT,
    IN p_firstname VARCHAR(50),
    IN p_lastname VARCHAR(50),
    IN p_contact VARCHAR(50),
    IN p_email VARCHAR(50)
)
BEGIN
    INSERT INTO clients (clientID, firstname, lastname, contact, email) 
    VALUES (p_clientID, p_firstname, p_lastname, p_contact, p_email);
END //

DELIMITER ;
-- b)call the procedure add a new client
CALL AddClient(3, 'Emma', 'Brown', '555-9876', 'emma.brown@example.com');

-- 2)a)procedure Get Properties Above a Certain Price
DELIMITER //

CREATE PROCEDURE GetPropertiesAbovePrice(IN p_price DECIMAL)
BEGIN
    SELECT * FROM properties WHERE price > p_price;
END //

DELIMITER ;
-- b)call the procedure
CALL GetPropertiesAbovePrice(200000);

-- 3)a)procedure 
DELIMITER //

CREATE PROCEDURE UpdatePropertieStatus(
    IN p_propertieID VARCHAR(10),
    IN p_newStatus VARCHAR(15)
)
BEGIN
    UPDATE properties SET statut = p_newStatus WHERE propertieID = p_propertieID;
END //

DELIMITER ;
-- b)call the procedure
CALL UpdatePropertieStatus('P001', 'Sold');

-- 4)a)procedure 
DELIMITER //

CREATE PROCEDURE AddTransaction(
    IN p_clientID INT,
    IN p_propertieID VARCHAR(10),
    IN p_agentID INT,
    IN p_transactionDate DATE,
    IN p_amount DECIMAL
)
BEGIN
    INSERT INTO transactions (clientID, propertieID, agentID, transactionDate, amount) 
    VALUES (p_clientID, p_propertieID, p_agentID, p_transactionDate, p_amount);
END //

DELIMITER ;
-- b)call the procedure
CALL AddTransaction(1, 'P002', 2, '2025-02-01', 180000);

-- 5)a)procedure
DELIMITER //

CREATE PROCEDURE DeletePayment(IN p_paymentID INT)
BEGIN
    DELETE FROM payments WHERE paymentID = p_paymentID;
END //

DELIMITER ;
-- b)call the procedure
CALL DeletePayment(1);

-- 6)procedure
DELIMITER //

CREATE PROCEDURE CountClientTransactions(IN p_clientID INT)
BEGIN
    SELECT COUNT(transactionID) AS total_transactions 
    FROM transactions 
    WHERE clientID = p_clientID;
END //

DELIMITER ;
-- b)call the procedure
CALL CountClientTransactions(1);


/*Triggers*/
DELIMITER //

-- Triggers for clients table
CREATE TRIGGER AfterClientInsert
AFTER INSERT ON clients
FOR EACH ROW
BEGIN
    INSERT INTO clients_logs (action, clientID, timestamp) 
    VALUES ('INSERT', NEW.clientID, NOW());
END //

CREATE TRIGGER AfterClientUpdate
AFTER UPDATE ON clients
FOR EACH ROW
BEGIN
    INSERT INTO client_logs (action, clientID, timestamp) 
    VALUES ('UPDATE', NEW.clientID, NOW());
END //

CREATE TRIGGER AfterClientDelete
AFTER DELETE ON clients
FOR EACH ROW
BEGIN
    INSERT INTO client_logs (action, clientID, timestamp) 
    VALUES ('DELETE', OLD.clientID, NOW());
END //

-- Triggers for properties table
CREATE TRIGGER AfterPropertyInsert
AFTER INSERT ON properties
FOR EACH ROW
BEGIN
    INSERT INTO property_logs (action, propertieID, timestamp) 
    VALUES ('INSERT', NEW.propertieID, NOW());
END //

CREATE TRIGGER AfterPropertyUpdate
AFTER UPDATE ON properties
FOR EACH ROW
BEGIN
    INSERT INTO property_logs (action, propertieID, timestamp) 
    VALUES ('UPDATE', NEW.propertieID, NOW());
END //

CREATE TRIGGER AfterPropertyDelete
AFTER DELETE ON properties
FOR EACH ROW
BEGIN
    INSERT INTO property_logs (action, propertieID, timestamp) 
    VALUES ('DELETE', OLD.propertieID, NOW());
END //

-- Triggers for agents table
CREATE TRIGGER AfterAgentInsert
AFTER INSERT ON agents
FOR EACH ROW
BEGIN
    INSERT INTO agent_logs (action, agentID, timestamp) 
    VALUES ('INSERT', NEW.agentID, NOW());
END //

CREATE TRIGGER AfterAgentUpdate
AFTER UPDATE ON agents
FOR EACH ROW
BEGIN
    INSERT INTO agent_logs (action, agentID, timestamp) 
    VALUES ('UPDATE', NEW.agentID, NOW());
END //

CREATE TRIGGER AfterAgentDelete
AFTER DELETE ON agents
FOR EACH ROW
BEGIN
    INSERT INTO agent_logs (action, agentID, timestamp) 
    VALUES ('DELETE', OLD.agentID, NOW());
END //

-- Triggers for transactions table
CREATE TRIGGER AfterTransactionInsert
AFTER INSERT ON transactions
FOR EACH ROW
BEGIN
    INSERT INTO transaction_logs (action, transactionID, timestamp) 
    VALUES ('INSERT', NEW.transactionID, NOW());
END //

CREATE TRIGGER AfterTransactionUpdate
AFTER UPDATE ON transactions
FOR EACH ROW
BEGIN
    INSERT INTO transaction_logs (action, transactionID, timestamp) 
    VALUES ('UPDATE', NEW.transactionID, NOW());
END //

CREATE TRIGGER AfterTransactionDelete
AFTER DELETE ON transactions
FOR EACH ROW
BEGIN
    INSERT INTO transaction_logs (action, transactionID, timestamp) 
    VALUES ('DELETE', OLD.transactionID, NOW());
END //

-- Triggers for payments table
CREATE TRIGGER AfterPaymentInsert
AFTER INSERT ON payments
FOR EACH ROW
BEGIN
    INSERT INTO payment_logs (action, paymentID, timestamp) 
    VALUES ('INSERT', NEW.paymentID, NOW());
END //

CREATE TRIGGER AfterPaymentUpdate
AFTER UPDATE ON payments
FOR EACH ROW
BEGIN
    INSERT INTO payment_logs (action, paymentID, timestamp) 
    VALUES ('UPDATE', NEW.paymentID, NOW());
END //

CREATE TRIGGER AfterPaymentDelete
AFTER DELETE ON payments
FOR EACH ROW
BEGIN
    INSERT INTO payment_logs (action, paymentID, timestamp) 
    VALUES ('DELETE', OLD.paymentID, NOW());
END //

-- Triggers for maintenanceRequests table
CREATE TRIGGER AfterMaintenanceInsert
AFTER INSERT ON maintenanceRequests
FOR EACH ROW
BEGIN
    INSERT INTO maintenance_logs (action, requestID, timestamp) 
    VALUES ('INSERT', NEW.requestID, NOW());
END //

CREATE TRIGGER AfterMaintenanceUpdate
AFTER UPDATE ON maintenanceRequests
FOR EACH ROW
BEGIN
    INSERT INTO maintenance_logs (action, requestID, timestamp) 
    VALUES ('UPDATE', NEW.requestID, NOW());
end //

create trigger AfterMaintenanceDelete
after delete on maintenanceRequests
for each row
begin
    insert into maintenance_logs (action, requestID, timestamp) 
    values ('DELETE', OLD.requestID, NOW());
end //

DELIMITER ;


-- To Verify the User’s Privileges:
show grants for 'RealEstateUser'@'localhost';


