create database configuration;
use configuration;

-- Create user and grant somes privileges
create user 'RealEstateUser'@'127.0.0.1' identified by 'Password123';
grant create,select,insert,execute,update on realEstateDB.properties to 'realEstateUser'@'127.0.0.1';
flush privileges;
